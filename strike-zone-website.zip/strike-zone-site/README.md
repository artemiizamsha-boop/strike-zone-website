# STRIKE ZONE — Official Website

A simple landing page for the STRIKE ZONE browser game.

## Files
- `index.html` — official website landing page.
- `game.html` — uploaded game build.

## Publish with GitHub Pages
1. Upload both `index.html` and `game.html` to the root of your GitHub repository.
2. Open repository Settings → Pages.
3. Under Build and deployment, choose Deploy from a branch.
4. Select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the website.

The game currently runs as HTML in a browser. This package does not contain native `.exe` or `.apk` installers.
